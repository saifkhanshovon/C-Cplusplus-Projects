#include <iostream>
#include <Windows.h>
#include <cstdlib>
using namespace std;

void clearscreen()
{
    HANDLE hOut;
    COORD Position;

    hOut = GetStdHandle(STD_OUTPUT_HANDLE);

    Position.X = 0;
    Position.Y = 0;
    SetConsoleCursorPosition(hOut, Position);
}

class game {
    public:
        char handler();
};

char game :: handler () {
    char map[30][30];
    int y = 16, x = 9; //the cars coordinates
    int a = 0, b = rand() % 15 ; //the obstacles coordiantes
    int points = 0; //points
    int speed = 100; //determines the speed of the obstacles
    char obstacle =25 ;

    //loads the map with spaces and border
    for(int i=0; i < 20; ++i) {
      for(int j=0; j < 20; ++j) {
        map[i][0] = '!';
        map[i][18] = '!';
        map[i][j] = ' ';
      }
    }

    //the game loop
    while(1) {

       map[y][x] = '^'; //first place of the car

       clearscreen();

      //the obstacles
        map[a][b] = ' ';
        map[a][b+1] = ' ';
        map[a][b-1] = ' ';
        map[a+1][b-1] = ' ';
        map[a+1][b+1] = ' ';
        map[a-1][b-1] = ' ';
        map[a-1][b+1] = ' ';
        ++a;
        map[a][b] = obstacle;
        map[a][b+1] = obstacle;
        map[a][b-1] = obstacle;
        if(a > 20) {
          a = 0;
          b = rand() % 15+1;
        }

    //the map
    for(int i=0; i < 20; ++i) {
      for(int j=0; j < 20; ++j) {
        cout << map[i][j];
          if(j >= 19) {
            cout << endl;
          }
        }
      }

    cout << "    Points: " << points ;

    //moves the car to the left
    if(GetAsyncKeyState(VK_LEFT)) {
      if(map[y][x] == obstacle) {
        goto lost;
      }
      else if(map[y][x-3] != '!') {
        map[y][x] = ' ';
        map[y][x+1] = ' ';
        map[y][x-1] = ' ';
        map[y+1][x-1] = ' ';
        map[y+1][x+1] = ' ';
        map[y-1][x-1] = ' ';
        map[y-1][x+1] = ' ';
        x -= 3;
        map[y][x] = '^';
      }
    }

    //moves the car to the right
    if(GetAsyncKeyState(VK_RIGHT)) {
      if(map[y][x] == obstacle) {
        goto lost;
      }
      else if(map[y][x+3] != '!') {
        map[y][x] = ' ';
        map[y][x+1] = ' ';
        map[y][x-1] = ' ';
        map[y+1][x-1] = ' ';
        map[y+1][x+1] = ' ';
        map[y-1][x-1] = ' ';
        map[y-1][x+1] = ' ';
        x += 3;
        map[y][x] = '^';
      }
    }

    ++points;

    //checks if the car crashed
    if(map[y][x] == obstacle){
    lost:
      cout << "\n\nGame over\n" << endl;
      cin.get();
      return 0;
    }

    //speeds up the obstacles each time the player gets 100+ points
    if(points == 100 || points == 200 || points == 300 || points == 400) {
        speed -= 25;
      }
    Sleep(speed);
    }
}

int main()
{
    game object;
    object.handler();
    return 0;
}

